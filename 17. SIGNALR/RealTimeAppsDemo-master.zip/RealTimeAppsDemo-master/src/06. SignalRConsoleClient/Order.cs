﻿namespace SignalRConsoleClient
{
    public class Order
    {
        public string Product { get; set; }

        public string Size { get; set; }
    }
}
