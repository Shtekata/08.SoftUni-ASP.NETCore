﻿namespace SharedLibrary
{
    public class CheckResult
    {
        public bool New { get; set; }

        public string Update { get; set; }

        public bool Finished { get; set; }
    }
}
