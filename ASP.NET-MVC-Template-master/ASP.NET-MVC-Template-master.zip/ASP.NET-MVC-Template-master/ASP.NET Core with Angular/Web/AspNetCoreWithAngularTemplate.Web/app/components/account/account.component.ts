﻿import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'account',
    templateUrl: 'account.component.html'
})

export class AccountComponent { }
