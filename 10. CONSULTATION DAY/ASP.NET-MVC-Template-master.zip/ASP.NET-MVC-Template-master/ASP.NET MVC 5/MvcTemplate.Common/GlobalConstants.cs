﻿namespace MvcTemplate.Common
{
    public class GlobalConstants
    {
        public const string AdministratorRoleName = "Administrator";
        public const int PasswordMinLength = 1;
    }
}
