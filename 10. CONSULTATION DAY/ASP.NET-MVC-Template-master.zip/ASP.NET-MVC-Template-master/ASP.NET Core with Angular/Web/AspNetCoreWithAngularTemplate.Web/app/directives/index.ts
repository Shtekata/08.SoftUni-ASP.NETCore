﻿export const APP_DIRECTIVES = [];
