## How to run the project

1. Open the project with Visual Studio 2017
2. Restore npm packages
3. Run gulp dev