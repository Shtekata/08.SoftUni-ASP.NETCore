﻿namespace AspNetCoreTemplate.Common
{
    public static class GlobalConstants
    {
        public const string SystemName = "AspNetCoreTemplate";

        public const string AdministratorRoleName = "Administrator";
    }
}
